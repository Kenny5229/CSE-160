Assignment 0
